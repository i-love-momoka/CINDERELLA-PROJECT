package com.example.render2d;


import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Random;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;



class Enemy {
    public boolean      sw;
    public float        x;
    public float        y;
    public float        addx;
    public float        addy;
}



public class RenderMain implements GLSurfaceView.Renderer {

    public GLSurfaceView   mContext;
    public Context context;
    public Random  rand = new Random(12345);
    public Enemy   enemy[];
    public float   spriteArrays[];
    public long    time_start = 0,time_end = 0,time_fpscnt,time_fps;


    RenderMain(GLSurfaceView mGLSurfaceView) {

        super();
        mContext = mGLSurfaceView;
        context = mContext.getContext();

    }


    public byte[] file2data(int r) {

        int size;
        byte[] w = new byte[1024];
        Resources res;

        res = context.getResources();
        InputStream in = res.openRawResource(r);
        ByteArrayOutputStream out = null;
        try {
            out = new ByteArrayOutputStream();
            while (true) {
                size = in.read(w);
                if (size <= 0) break;
                out.write(w, 0, size);
            }
            out.close();
            in.close();
            // ByteArrayOutputStream
            return out.toByteArray();
        } catch (Exception e) {
        }
        return out.toByteArray();
    }

    public void CreateTexture(int texNum, int res_id) {

        byte    png[] = file2data(res_id);
        JniBridge.CreateTexture(texNum, png, png.length);

    }

    public void CreateTexture2(int texNum, int res_id) {

        Bitmap  bm = BitmapFactory.decodeResource(context.getResources(), res_id);
        JniBridge.CreateTexture2(bm, texNum);

    }


    @Override
    public void onSurfaceCreated(GL10 gl10, EGLConfig eglConfig) {

        int     i,j;

        JniBridge.Initialize();

        enemy = new Enemy[Val.ENEMY_MAX];
        for(i = 0;i < Val.ENEMY_MAX;i++) {
            enemy[i] = new Enemy();
            enemy[i].sw = true;
            enemy[i].x = rand.nextInt(1280);
            enemy[i].y = rand.nextInt(720);
            enemy[i].addx = (float)(rand.nextInt(4000) - 2000) / 1000.0f;
            enemy[i].addy = (float)(rand.nextInt(4000) - 2000) / 1000.0f;
        }

        spriteArrays = new float[8 * Val.ENEMY_MAX];    // (tx,ty,tw,th,x,y,w,h) * Val.ENEMY_MAX

        CreateTexture(Val.tx_font, R.raw.font);
        CreateTexture(Val.tx_bg, R.raw.boot);
        CreateTexture(Val.tx_enemy, R.raw.enemy);

    }


    @Override
    public void onSurfaceChanged(GL10 gl10, int w, int h) {

        JniBridge.onSurfaceChanged( w, h);

    }


    // 1/60秒毎に呼び出される描画プログラム
    @Override
    public void onDrawFrame(GL10 gl10) {

        if(Param.bPause) return;

        // fpsの計測 - fps (frame per second)
        time_fpscnt++;
        time_end = System.currentTimeMillis();
        if(time_end - time_start >= 1000) {
            time_fps = time_fpscnt;
            time_fpscnt = 0;
            time_start = time_end;
        }

        // レンダリングメイン
        JniBridge.drawMain();
        JniBridge.drawFPS((int) time_fps);

    }

}

// [EOF]
