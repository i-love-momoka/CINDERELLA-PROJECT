package com.example.render2d;


/*--------------------------------------------------------------

    C/C++言語の関数を実行するJavaクラス

--------------------------------------------------------------*/


import android.graphics.Bitmap;

public class JniBridge {

    static {
        System.loadLibrary("native-lib");   // C/C++ライブラリの名前
    }

    public static native int Initialize();
    public static native void onSurfaceChanged(int w, int h);
    public static native int drawMain();
    public static native void drawFPS(int fps);
    public static native void CreateTexture(int texNum, byte pngmem[], int length);
    public static native void CreateTexture2(Bitmap bm, int texNum);
    public static native void makeTexture(int texNum, int w,int h);
    public static native void SetTextureImage(Bitmap bm, int x, int y, int w, int h, int texNum);
    public static native void addXY(float addx,float addy);
    public static native void ReleaseAll();
}
