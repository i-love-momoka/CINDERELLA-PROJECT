package com.example.render2d;


/*------------------------------------------------------------------------------


    【バーテックスシェーダーの座標計算によって異なる解像度を吸収して高速に2D描画する】


　　通常必要最低限の解像度のビットマップやテクスチャのターゲットを決めて
　　ターゲットにゲームの背景やキャラクターを描画し
　　その後にターゲットをフルスクリーンで画面に描画する事で全ての機種に画面対応している。

　　ただしこの方法だと若干処理速度に無駄が生じるので効率の良い方法を考えた。

　　今回はOpenGL-ES2.0のシェーダープログラムを使用する事にする。
　　画面解像度は機種毎によって違っているが、
　　例えば「1280×720ピクセル以上のLANDSCAPE画面解像度に対応」と決めて
　　「1280×720ピクセルのレンダリングターゲットがある」と仮定して
　　レンダリングターゲットと画面解像度の比率を求めて頂点座標に乗算して
　　左上座標系にシェーダーで書き込む事によって全ての機種の液晶解像度に対応できる。

　　しかも流行りのフレームバッファを使った方法と違って
　　一画面ぶんのメモリーへのピクセルのバッファリングという時間の無駄が無いので
　　高速な2Dキャラのレンダリング(描画)が実現可能です。


　　現在Androidプログラマーにのみこのソースの参考使用を許可しているので、
　　iPhone等の他のプラットフォームへの使用や改変改良使用は禁止しています。


------------------------------------------------------------------------------*/



import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;



public class Render2D extends Activity {

    public GLSurfaceView mGLSurfaceView;
    public float    tx,ty,tx2,ty2,kx,ky;


    @Override
    protected void onCreate(Bundle savedInstanceState) {    // 起動時に呼ばれる
        super.onCreate(savedInstanceState);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);     // 横画面
        requestWindowFeature(Window.FEATURE_NO_TITLE);                          // タイトルバー無し
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);       // フルスクリーンモード

        // RenderMainクラスをOpenGL-ES2.0実装して動作させる準備
        mGLSurfaceView = new GLSurfaceView(this);
        mGLSurfaceView.setEGLContextClientVersion(2);    // OpenGL ES 2.0
        RenderMain renderer = new RenderMain(mGLSurfaceView);
        mGLSurfaceView.setRenderer(renderer);
        // RenderMainクラスに制御を移す
        setContentView(mGLSurfaceView);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(Menu.NONE,0,0,"Stop / ReStart");
        menu.add(Menu.NONE,1,1,"Exit");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {   // Menuの選択肢ごとの処理

        int id = item.getItemId();

        if (id == 0) {          // Pause
            if (Param.bPause == true) {
                Param.bPause = false;
            }else{
                Param.bPause = true;
            }
            return true;
        }

        if (id == 1) {          // アプリ終了
            JniBridge.ReleaseAll();
            System.exit(0);
            return true;
        }

        return false;
    }


    public boolean onTouchEvent(MotionEvent event) {    // 画面をタッチした時の処理

        if(event.getAction() == MotionEvent.ACTION_DOWN) {  // 画面を押した時の処理

            tx = event.getX();
            ty = event.getY();

        } else if(event.getAction() == MotionEvent.ACTION_MOVE) {   // 押したまま座標が変わった時の処理

            tx2 = tx;
            ty2 = ty;
            tx = (int)event.getX();
            ty = (int)event.getY();
            kx = tx - tx2;
            ky = ty - ty2;

            if((kx <= 1.0f) && (kx >= -1.0f)) kx = 0.0f;
            if((ky <= 1.0f) && (ky >= -1.0f)) ky = 0.0f;
            Param.addx = kx;
            Param.addy = ky;
            JniBridge.addXY(kx,ky);

        } else if(event.getAction() == MotionEvent.ACTION_UP) {     // 画面から指を離した時の処理

            kx = 0;
            ky = 0;

        }
        return false;
    }

}

// [EOF]
