package com.example.render2d;


public class Param {
    public static boolean   bPause = false;
    public static float     addx = 0.0f;
    public static float     addy = 0.0f;
}
