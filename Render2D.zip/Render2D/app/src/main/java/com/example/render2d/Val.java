package com.example.render2d;


public class Val {

    public static final int         ENEMY_MAX = 1024;

    public static final int         tx_font = 0;
    public static final int         tx_bg = 1;
    public static final int         tx_enemy = 2;

}
