#include <jni.h>
//#include <stdio.h>
//#include <stdlib.h>
//#include <malloc.h>
#include "png.h"
#include "assert.h"
#include "string.h"
#include "GLES2/gl2.h"
#include "GLES2/gl2ext.h"
#include "../Texture.h"


#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT void JNICALL Java_com_example_render2d_JniBridge_CreateTexture(JNIEnv* env, jobject obj, int texNum, jbyteArray pngmem, int length);

#ifdef __cplusplus
}
#endif






#define     u8 unsigned char

//
//extern      GLuint texture[];
//extern      int texsizeW[];
//extern      int texsizeH[];
extern      Texture texture[];
extern      GLuint  textures[1];



enum
{
    FORMAT_RGBA,
    FORMAT_RGB,
};


//GLuint  texture;                        // テクスチャオブジェクト
short   format;                         // テクスチャフォーマット
int   width, height;                  // サイズ
u8    *pngdata = 0;
png_uint_32     _width, _height;
int             _bit_depth, _color_type;
//static  GLuint  textures[1];




void    png_read(png_structp png_ptr, png_bytep data, png_size_t length)
{
    u8**    _p = (u8**)png_get_io_ptr(png_ptr);         // データポインタ

    memcpy(data, *_p, length);
    *_p += length;
}

//void Java_com_Luminance_DestructionForce_JniBridge_LoadPng(JNIEnv* env, jobject obj, u8 jbyteArray pngmem, int length)
 void LoadPng(u8 *pngmem, int length)
{
    int     i,j,k;

    png_structp     _png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    assert(_png);

    png_infop       _info = png_create_info_struct(_png);
    assert(_info);

    png_set_read_fn(_png, NULL, png_read);
    png_init_io(_png, (png_FILE_p)&pngmem);
    png_read_info(_png, _info);

    png_uint_32     _width, _height;
    int             _bit_depth, _color_type;

    png_get_IHDR(_png, _info, &_width, &_height, &_bit_depth, &_color_type, NULL, NULL, NULL);
    switch ( _color_type ) {
        case PNG_COLOR_TYPE_RGB :
            format = FORMAT_RGB;
            break;

        case PNG_COLOR_TYPE_PALETTE :
            png_set_palette_to_rgb(_png);
            png_read_update_info(_png, _info);
            png_get_IHDR(_png, _info, &_width, &_height, &_bit_depth, &_color_type, NULL, NULL, NULL);
            format = (_color_type == PNG_COLOR_TYPE_RGB) ? FORMAT_RGB : FORMAT_RGBA;
            break;

        case PNG_COLOR_TYPE_GRAY :
            png_set_gray_to_rgb(_png);
            png_read_update_info(_png, _info);
            format = FORMAT_RGB;
            break;

        case PNG_COLOR_TYPE_GRAY_ALPHA :
            png_set_gray_to_rgb(_png);
            png_read_update_info(_png, _info);
            format = FORMAT_RGBA;
            break;

        default :
            format = FORMAT_RGBA;
            break;
    }

    width  = (short)_width;
    height = (short)_height;

    int         _row_bytes = width*((format == FORMAT_RGBA) ? 4 : 3);
    u8*         _buf = (u8*)memalign(4, _row_bytes*height);
    png_bytep   _rows[height];

    assert(_buf != NULL);
    for (int i = 0; i < height; i++) {
        _rows[i] = _buf + i*_row_bytes;
    }
    png_read_image(_png, _rows);



//    make(_buf);             // テクスチャ作成

    if(format == FORMAT_RGB) {

        k = width * height * 4;
        pngdata = (u8*)malloc(size_t(k * 4));
        for (i = 0;i < k;i++) {
            pngdata[i] = _buf[i];
        }

    } else if(format == FORMAT_RGBA) {

        k = width * height * 4;
        pngdata = (u8 *) malloc(size_t(k));
        for (i = 0; i < k; i++) {
            pngdata[i] = _buf[i];
        }

    }

    png_destroy_read_struct(&_png, &_info, NULL);
    free(_buf);
}

void Java_com_example_render2d_JniBridge_CreateTexture(JNIEnv* env, jobject obj, int texNum, jbyteArray pngmem, int length)
{
    int     i,j;

    u8 *pngptr = (u8 *) env->GetPrimitiveArrayCritical( pngmem, 0);

    u8 *png = (u8 *)malloc(size_t(length));
    for(i = 0;i < length;i++) {
        png[i] = pngptr[i];
    }


    LoadPng(png, length);

    glActiveTexture(GL_TEXTURE0);
    glGenTextures(1,textures);
    texture[texNum].lpTexture = textures[0];
    texture[texNum].width = width;
    texture[texNum].height = height;
    glBindTexture(GL_TEXTURE_2D, texture[texNum].lpTexture);
    glTexImage2D(GL_TEXTURE_2D,0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, pngdata);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    free(png);
    free(pngdata);

    env->ReleasePrimitiveArrayCritical( pngmem, pngptr, JNI_ABORT);
}


// [EOF]

