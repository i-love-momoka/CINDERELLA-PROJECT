


typedef struct {
    char				filename[256];
    unsigned char		*lpData;
    GLuint				lpTexture;
    int 				width;
    int 				height;
} Texture;

