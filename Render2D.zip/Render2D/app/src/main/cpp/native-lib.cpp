#include <jni.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <GLES/gl.h>
#include <GLES2/gl2.h>
#include <android/bitmap.h>
#include "Matrix.h"
#include "Texture.h"


#ifdef __cplusplus
extern "C" {
#endif

int JNICALL Java_com_example_render2d_JniBridge_Initialize(JNIEnv* env, jobject obj);
void JNICALL Java_com_example_render2d_JniBridge_onSurfaceChanged(JNIEnv* env, jobject obj, int w, int h);
int JNICALL Java_com_example_render2d_JniBridge_drawMain(JNIEnv* env, jobject obj);
void JNICALL Java_com_example_render2d_JniBridge_CreateTexture2(JNIEnv* env,jobject thiz, jobject bm,int texNum);
void JNICALL Java_com_example_render2d_JniBridge_makeTexture(JNIEnv* env,jobject thiz, int texNum, int w, int h);
void JNICALL Java_com_example_render2d_JniBridge_SetTextureImage(JNIEnv* env,jobject thiz, jobject bm, int x, int y, int w, jint h, jint texNum);
void JNICALL Java_com_example_render2d_JniBridge_SetTextTexture(JNIEnv* env,jobject thiz, jobject bm, int x, int y, int w, int h, int texNum);
void JNICALL Java_com_example_render2d_JniBridge_ReleaseAll(JNIEnv* env, jobject obj);
void JNICALL Java_com_example_render2d_JniBridge_addXY(JNIEnv* env, jobject obj,float addx,float addy);
void JNICALL Java_com_example_render2d_JniBridge_drawFPS(JNIEnv* env, jobject obj, int fps);
void JNICALL Java_com_example_render2d_JniBridge_clearText(JNIEnv* env, jobject obj,jobject bm);

#ifdef __cplusplus
}
#endif

#define TEXTURE_MAX 1024
#define SPRITE_MAX  1024
#define ENEMY_MAX   1024

enum {
    tx_font = 0,
    tx_bg = 1,
    tx_enemy = 2,
};

typedef struct {
    int     num;
    float   x;
    float   y;
    float   addx;
    float   addy;
} ENEMY;
ENEMY   enemy[ENEMY_MAX];


int     viewW;
int     viewH;

GLuint  textures[1];
Texture  texture[1024];

GLuint program;
GLuint position;
GLuint texcoord;
GLuint color;
GLuint projection;
GLuint localview;
GLuint modelpos;
GLuint modelxyz;
GLuint lookat;
GLuint screensize;
GLuint screen_size;

Matrix matrix;
Matrix LookAt;
Matrix Projection;
Matrix trans;
Matrix Translate;

float mat_projection[4 * 4];
float mat_lookat[4 * 4];
float mat_local[4 * 4];

float vertex_font_temp[3 * 3 * 2 * 160],*vertex_font;
float texpos_font_temp[2 * 3 * 2 * 160],*texpos_font;
float color_font_temp[4 * 3 * 2 * 160],*color_font;




void set_gpu_value();
void putString(int x,int y,char *fval);
void drawSprite(int texNum,float tx,float ty,float tw,float th, float x, float y, float w, float h, float z);



int Java_com_example_render2d_JniBridge_Initialize(JNIEnv* env, jobject obj) {

    int     i;
    int     result = 0;

    srand(12345);

    set_gpu_value();

    glEnable(GL_TEXTURE_2D);
    glActiveTexture(GL_TEXTURE0);

    glDisable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glDepthFunc(GL_LESS);

    glEnable(GL_CULL_FACE);
    glFrontFace(GL_CCW);
    glCullFace(GL_BACK);

    return result;
}


void Java_com_example_render2d_JniBridge_addXY(JNIEnv* env, jobject obj,float addx,float addy) {

//    mx_addx = addx;
//    my_addy = addy;

}


int     val[256];
char    str_val[256];

void putValue(int x, int y, int value) {

    int index = 0,i;
    int a;

    while(true) {

        a = value % 10;
        val[index++] = a;
        value /= 10;
        if(value <= 0) break;
    }

    i = 0;
    while(true) {

        a = val[--index];
        if(index < 0) {
            str_val[i] = 0;
            break;
        }
        str_val[i++] = (char)('0' + (char)a );

    }

    putString(x,y,str_val);

}

void putString(int x, int y, char *str) {

    char a;
    float sx, sy;
    float ratio = (float) viewH / (float) viewW;
    float dotsizeX = 2.0f / (float)viewW;
    float dotsizeY = 2.0f / (float)viewH;
    float aspect = 1.0f;//(float)viewH / (float)viewW;
    float addy = dotsizeY * (float)((float)viewH / (float)viewW);
    int     strides,i;

    glBindTexture(GL_TEXTURE_2D, texture[tx_font].lpTexture);
    glUniform1i(texture[tx_font].lpTexture, 0);

    vertex_font = vertex_font_temp;
    texpos_font = texpos_font_temp;
    color_font = color_font_temp;
    strides = 0;

    while (true) {
        a = *(str++);
        if (a == 0) {
            break;
        } else if ((a >= 'a') && (a <= 'z')) {
            sx = (float) (a - 'a') * 8 + 8;
            sy = 0;
        } else if ((a >= 'A') && (a <= 'Z')) {
            sx = (float) (a - 'A') * 8 + 8;
            sy = 8;
        } else if ((a >= '0') && (a <= '9')) {
            sx = (float) (a - '0') * 8 + 0;
            sy = 16;
        } else if (a == '=') {
            sx = 32;
            sy = 24;
        } else {
            sx = 0.0f;
            sy = 0.0f;
        }


        vertex_font[0] = x;
        vertex_font[1] = y;
        vertex_font[2] = 1.0f;

        vertex_font[3] = x;
        vertex_font[4] = (y + 16.0f);
        vertex_font[5] = 1.0f;

        vertex_font[6] = (x + 16.0f);
        vertex_font[7] = y;
        vertex_font[8] = 1.0f;

        vertex_font[9] = (x + 16.0f);
        vertex_font[10] = y;
        vertex_font[11] = 1.0f;

        vertex_font[12] = x;
        vertex_font[13] = (y + 16.0f);
        vertex_font[14] = 1.0f;

        vertex_font[15] = (x + 16.0f);
        vertex_font[16] = (y + 16.0f);
        vertex_font[17] = 1.0f;


        texpos_font[0] = sx / 256.0f;
        texpos_font[1] = sy / 256.0f;
        texpos_font[2] = sx / 256.0f;
        texpos_font[3] = (sy + 8.0f) / 256.0f;
        texpos_font[4] = (sx + 8.0f) / 256.0f;
        texpos_font[5] = sy / 256.0f;
        texpos_font[6] = (sx + 8.0f) / 256.0f;
        texpos_font[7] = sy / 256.0f;
        texpos_font[8] = sx / 256.0f;
        texpos_font[9] = (sy + 8.0f) / 256.0f;
        texpos_font[10] = (sx + 8.0f) / 256.0f;
        texpos_font[11] = (sy + 8.0f) / 256.0f;

        for(i = 0;i < 4 * 6;i++) {
            color_font[i] = 1.0f;
        }

        x += 16;
        vertex_font += 18;
        texpos_font += 12;
        color_font += 24;
        strides += 6;
    }

    glVertexAttribPointer(position, 3, GL_FLOAT, GL_FALSE, 0, vertex_font_temp);
    glVertexAttribPointer(texcoord, 2, GL_FLOAT, GL_FALSE, 0, texpos_font_temp);
    glVertexAttribPointer(color, 4, GL_FLOAT, GL_FALSE, 0, color_font_temp);
    glDrawArrays(GL_TRIANGLES, 0, strides);

}


void set_AlphaBlend(bool b)
{
    if (b == true) {
        glEnable(GL_BLEND);
    } 	else {
        glDisable(GL_BLEND);
    }
}



void lookAt(float ex,float ey,float ez,float cx,float cy,float cz,float rx,float ry,float rz) {

    LookAt.newLookAt(
            ex, ey, ez,        // eye
            cx, cy, cz,    // center
            0.0f, 1.0f, 0.0f);        // up
    glUniformMatrix4fv(lookat, 1, GL_FALSE, &LookAt.mData[0]);

}

void calc_projection()
{
    int i, j, f, a;

    //プロジェクション行列設定
    static float ratio = (float) viewW / (float) viewH;
    for (int i = 0; i < 4 * 4; i++) {              // 透視変換行列初期化
        mat_projection[i] = 0.0f;
    }
    float _x = (1.0f) - (-1.0f);
    float _y = (1.0f) - (-1.0f);
    float _z = (1000.0f) - (1.0f);
    mat_projection[0] = 2.0f / _x;                    // 画面横幅
    mat_projection[5] = 2.0f / _y * (ratio);            // 画面縦幅
    mat_projection[10] = -2.0f / _z;                    // カメラ手前クリッピングZ座標
    mat_projection[15] = 1.0f;                            // w = 1.0f
    mat_projection[3] = -(((1.0f) + (-1.0f)) / ((1.0f) - (-1.0f)));
    mat_projection[7] = -(((1.0f) + (-1.0f)) / ((1.0f) - (-1.0f)));
    mat_projection[11] = -((1000.0f + 1.0f) / (1000.0f - 1.0f));
    for (i = 0; i < 16; i++) {
        Projection.mData[i] = mat_projection[i];
    }

}

void set_projection() {

    trans.identity();
    trans.multiply(Projection, LookAt);
    glUniformMatrix4fv(projection, 1, GL_FALSE, &trans.mData[0]);

}


static const char VERTEX_SHADER[] =
        "attribute vec4 position;"
                "varying vec4 vColor;"
                "varying vec2 texcoordVarying;"
                "attribute vec2 texcoord;"
                "attribute vec4 color;"
                "uniform vec2 screen_size;"

                "void main() {"

                "vec4 pos = position;"
                "float multi = screen_size.x / 1280.0;"

                "pos.x = multi * pos.x;"
                "pos.y = multi * pos.y;"

                "float dotW =  2.0 / screen_size.x;"
                "float dotH =  2.0 / screen_size.y;"

                "pos.x =  -1.0 + ( dotW * pos.x);"
                "pos.y =   1.0 - ( dotH * pos.y);"

                "gl_Position = pos;"
                "vColor = color;"
                "texcoordVarying = texcoord;"
                "}";

static const char FRAGMENT_SHADER[] =
        "precision mediump float;"
                "varying vec2 texcoordVarying;"
                "uniform sampler2D texture;"
                "varying vec4 vColor;"
                "void main() {"
                "gl_FragColor = texture2D(texture, texcoordVarying) * vColor;"
                "}";



static GLuint loadShader(GLenum shaderType, const char *shaderCode) {
    GLuint shader = glCreateShader(shaderType);
    if (shader != 0) {
        glShaderSource(shader, 1, &shaderCode, NULL);
        glCompileShader(shader);
        GLint compiled = 0;
        glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
        if (!compiled) {
            GLint infoLen = 0;
            glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infoLen);
            if (infoLen) {
                char *buf = (char *) malloc(infoLen);
                if (buf) {
                    glGetShaderInfoLog(shader, infoLen, NULL, buf);
                    free(buf);
                }
            }
            glDeleteShader(shader);
        }
    }
    return shader;
}

static GLuint createProgram(const char *vertexCode, const char *fragmentCode) {

    GLuint vertexShader = loadShader(GL_VERTEX_SHADER, vertexCode);
    if (!vertexShader) {
        return 0;
    }

    GLuint pixelShader = loadShader(GL_FRAGMENT_SHADER, fragmentCode);
    if (!pixelShader) {
        return 0;
    }

    GLuint program = glCreateProgram();
    if (program) {
        glAttachShader(program, vertexShader);
        glAttachShader(program, pixelShader);

        glLinkProgram(program);
        GLint linkStatus = GL_FALSE;
        glGetProgramiv(program, GL_LINK_STATUS, &linkStatus);
        if (linkStatus != GL_TRUE) {
            GLint bufLength = 0;
            glGetProgramiv(program, GL_INFO_LOG_LENGTH, &bufLength);
            if (bufLength) {
                char *buf = (char *) malloc(bufLength);
                if (buf) {
                    glGetProgramInfoLog(program, bufLength, NULL, buf);
                    free(buf);
                }
            }
            glDeleteProgram(program);
            program = 0;
        }
    }
    return program;
}

void set_gpu_value() {

    program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER);
    glUseProgram(program);

    position = glGetAttribLocation(program, "position");
    glEnableVertexAttribArray(position);

    texcoord = glGetAttribLocation(program, "texcoord");
    glEnableVertexAttribArray(texcoord);

    color = glGetAttribLocation(program, "color");            // カラー
    glEnableVertexAttribArray(color);

    screensize = glGetAttribLocation(program, "screensize");            // screen size
    glEnableVertexAttribArray(screensize);


    screen_size = glGetUniformLocation(program, "screen_size");            // screen size

    projection = glGetUniformLocation(program, "projection");      // 透視変換
    glUniformMatrix4fv(projection, 1, GL_FALSE, mat_projection);

    localview = glGetUniformLocation(program, "localview");      // 回転
    glUniformMatrix4fv(localview, 1, GL_FALSE, mat_local);

    modelpos = glGetUniformLocation(program, "modelpos");      // 座標移動
    glUniformMatrix4fv(modelpos, 1, GL_FALSE, mat_local);

    lookat = glGetAttribLocation(program, "lookat");
    glUniformMatrix4fv(lookat, 1, GL_FALSE, mat_lookat);

    return;
}


void Java_com_example_render2d_JniBridge_onSurfaceChanged(JNIEnv* env, jobject obj, jint w, jint h) {

    float   aspect;

    aspect = 9.0f / 16.0f;
    viewW = w;
    viewH = w * aspect;
    glViewport( 0, 0, viewW, viewH);

}


void Java_com_example_render2d_JniBridge_CreateTexture2(JNIEnv* env,jobject thiz, jobject bm,int texNum)
{
    AndroidBitmapInfo info;
    void *pixels;
    int ret, i, j, x, y, dot;
    int *sptr, *bmptr;

    if ((AndroidBitmap_getInfo(env, bm, &info)) < 0) {
    }
    if ((AndroidBitmap_lockPixels(env, bm, &pixels)) < 0) {
    }

    texture[texNum].width = info.width;
    texture[texNum].height = info.height;

    glGenTextures(1,textures);
    texture[texNum].lpTexture = textures[0];
    glBindTexture(GL_TEXTURE_2D, texture[texNum].lpTexture);
    glTexImage2D(GL_TEXTURE_2D,0, GL_RGBA, info.width, info.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, /*GL_LINEAR*/GL_NEAREST);

    AndroidBitmap_unlockPixels(env, bm);

    return;
}

void Java_com_example_render2d_JniBridge_makeTexture(JNIEnv* env,jobject thiz, int texNum, int w, int h)
{
    int *pixels;
    int i;


    texture[texNum].width = w;
    texture[texNum].height = h;

    pixels = (int*)malloc( w * h * 4);

    for(i = 0;i < w * h;i++) {
        pixels[i] = 0x00000000;
    }

    glGenTextures(1,textures);
    texture[texNum].lpTexture = textures[0];
    glBindTexture(GL_TEXTURE_2D, texture[texNum].lpTexture);
    glTexImage2D(GL_TEXTURE_2D,0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    free(pixels);

    return;
}

void Java_com_example_render2d_JniBridge_SetTextureImage(
    JNIEnv* env,jobject thiz, jobject bm, int x, int y, int w, int h, int texNum)
{
    void *pixels;

    if ((AndroidBitmap_lockPixels(env, bm, &pixels)) < 0) {
    }

    glBindTexture(GL_TEXTURE_2D, texture[texNum].lpTexture);
   	glTexSubImage2D(GL_TEXTURE_2D, 0, x, y, w, h, GL_RGBA, GL_UNSIGNED_BYTE, pixels);

    AndroidBitmap_unlockPixels(env, bm);

    return;
}

int     textbuf[1280 * 720];
float   vtx_text[3 * 4];
float   uv_text[2 * 4];

void Java_com_example_render2d_JniBridge_SetTextTexture(
    JNIEnv* env,jobject thiz,
    jobject bm, int x, int y, int w, int h, int texNum)
{
    void *pixels;
    int i, j, k;
    int *sptr;

    if ((AndroidBitmap_lockPixels(env, bm, &pixels)) < 0) {
    }

    k = 0;
    sptr = (int*)pixels;
    sptr += 1280 * y + x;
    for(i = 0;i < h;i++) {
        for(j = 0;j < w;j++) {
            textbuf[k++] = sptr[1280 * i + j];
        }
    }

    glBindTexture(GL_TEXTURE_2D, texture[texNum].lpTexture);
   	glTexSubImage2D(GL_TEXTURE_2D, 0, x, y, w, h, GL_RGBA, GL_UNSIGNED_BYTE, textbuf);

    AndroidBitmap_unlockPixels(env, bm);

    return;
}

void Java_com_example_render2d_JniBridge_clearText(JNIEnv* env, jobject obj,jobject bm)
{
    AndroidBitmapInfo info;
    void *pixels;
    int i;
    int *sptr;

    if ((AndroidBitmap_getInfo(env, bm, &info)) < 0) {
    }
    if ((AndroidBitmap_lockPixels(env, bm, &pixels)) < 0) {
    }

    int     cnt = info.width * info.height;
    sptr = (int*)pixels;
    for(i = 0;i < cnt;i++) {
        sptr[i] = 0;
    }

    AndroidBitmap_unlockPixels(env, bm);

}



float   _vtx[3 * 3 * 2 * SPRITE_MAX/4], *vtx;
float   _uv[2 * 3 * 2 * SPRITE_MAX/4], *uv;
float   _luminance[4 * 3 * 2 * SPRITE_MAX/4],*luminance;
float   _vtx2[3 * 3 * 2 * SPRITE_MAX], *vtx2;
float   _uv2[2 * 3 * 2 * SPRITE_MAX], *uv2;
float   _luminance2[4 * 3 * 2 * SPRITE_MAX], *luminance2;
int     strides;

float   color_tbl[] = {
        1.0f, 1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 1.0f,
};


void drawSprite(int texNum,float tx,float ty,float tw,float th, float x, float y, float w, float h)
{
    float   texSizeW,texSizeH;

    texSizeW = texture[texNum].width;
    texSizeH = texture[texNum].height;
    vtx = _vtx;
    uv = _uv;
    luminance = _luminance;


    vtx[0] = x;
    vtx[1] = y;
    vtx[2] = 0.0f;

    vtx[3] = x;
    vtx[4] = (y + h);
    vtx[5] = 0.0f;

    vtx[6] = (x + w);
    vtx[7] = y;
    vtx[8] = 0.0f;

    vtx[9] = (x + w);
    vtx[10] = y;
    vtx[11] = 0.0f;

    vtx[12] = x;
    vtx[13] = (y + h);
    vtx[14] = 0.0f;

    vtx[15] = (x + w);
    vtx[16] = (y + h);
    vtx[17] = 0.0f;


    uv[0] = tx / texSizeW;
    uv[1] = ty / texSizeH;

    uv[2] = tx / texSizeW;
    uv[3] = (ty + th) / texSizeH;

    uv[4] = (tx + tw) / texSizeW;
    uv[5] = ty / texSizeH;

    uv[6] = (tx + tw) / texSizeW;
    uv[7] = ty / texSizeH;

    uv[8] = tx / texSizeW;
    uv[9] = (ty + th) / texSizeH;

    uv[10] = (tx + tw) / texSizeW;
    uv[11] = (ty + th) / texSizeH;


    glBindTexture(GL_TEXTURE_2D, texture[texNum].lpTexture);
    glUniform1i(texture[texNum].lpTexture, 0);
    glVertexAttribPointer(position,3, GL_FLOAT, GL_FALSE, 0, vtx);
    glVertexAttribPointer(texcoord,2, GL_FLOAT, GL_FALSE, 0, uv);
    glVertexAttribPointer(color,4, GL_FLOAT, GL_FALSE, 0, color_tbl);
    glDrawArrays(GL_TRIANGLES,0, 6);

}

void setSprite(int texNum, float tx,float ty,float tw,float th, float x, float y, float w, float h)
{
    int     i;
    float   texSizeW,texSizeH;

    texSizeW = texture[texNum].width;
    texSizeH = texture[texNum].height;


    vtx2[0] = x;
    vtx2[1] = y;
    vtx2[2] = 0.0f;

    vtx2[3] = x;
    vtx2[4] = (y + h);
    vtx2[5] = 0.0f;

    vtx2[6] = (x + w);
    vtx2[7] = y;
    vtx2[8] = 0.0f;

    vtx2[9] = (x + w);
    vtx2[10] = y;
    vtx2[11] = 0.0f;

    vtx2[12] = x;
    vtx2[13] = (y + h);
    vtx2[14] = 0.0f;

    vtx2[15] = (x + w);
    vtx2[16] = (y + h);
    vtx2[17] = 0.0f;

    vtx2 += 18;


    uv2[0] = tx / texSizeW;
    uv2[1] = ty / texSizeH;

    uv2[2] = tx / texSizeW;
    uv2[3] = (ty + th) / texSizeH;

    uv2[4] = (tx + tw) / texSizeW;
    uv2[5] = ty / texSizeH;

    uv2[6] = (tx + tw) / texSizeW;
    uv2[7] = ty / texSizeH;

    uv2[8] = tx / texSizeW;
    uv2[9] = (ty + th) / texSizeH;

    uv2[10] = (tx + tw) / texSizeW;
    uv2[11] = (ty + th) / texSizeH;

    uv2 += 12;


    for(i = 0;i < 4 * 6;i++) {
        luminance2[i] = 1.0f;
    }

    luminance2 += 24;

    strides += 6;

}

void drawSpriteArrays(int texNum)
{
    glBindTexture(GL_TEXTURE_2D, texture[texNum].lpTexture);
    glUniform1i(texture[texNum].lpTexture, 0);
    glVertexAttribPointer(position,3, GL_FLOAT, GL_FALSE, 0, _vtx2);
    glVertexAttribPointer(texcoord,2, GL_FLOAT, GL_FALSE, 0, _uv2);
    glVertexAttribPointer(color,4, GL_FLOAT, GL_FALSE, 0, _luminance2);
    glDrawArrays(GL_TRIANGLES,0, strides);
}


bool    bInitialize_Enemy = false;

void init_enemy()
{
    int     i;

    for(i = 0;i < ENEMY_MAX;i++) {
        enemy[i].num = 1;
        enemy[i].x = 1280.0f * (float)rand() / (float)RAND_MAX;
        enemy[i].y =  720.0f * (float)rand() / (float)RAND_MAX;
        enemy[i].addx = 8.0f * (float)rand() / (float)RAND_MAX -4.0f;
        enemy[i].addy = 8.0f * (float)rand() / (float)RAND_MAX -4.0f;
    }

}

void move_enemy()
{
    int     i;

    for(i = 0;i < ENEMY_MAX;i++) {
        enemy[i].x += enemy[i].addx;
        enemy[i].y += enemy[i].addy;
        if( (enemy[i].x < 0.0f) || (enemy[i].x >= 1280.0f) ) enemy[i].addx = -enemy[i].addx;
        if( (enemy[i].y < 0.0f) || (enemy[i].y >=  720.0f) ) enemy[i].addy = -enemy[i].addy;
        setSprite(tx_enemy,
            0.0f, 256.0f - 32.0f, 32.0f, 32.0f,
            enemy[i].x - 16.0f, enemy[i].y - 16.0f, 32.0f,32.0f);
    }

}

// onDrawFrame(GL10 gl10)から呼び出されるレンダリングルーチン
int Java_com_example_render2d_JniBridge_drawMain(JNIEnv* env, jobject obj)
{

    if(bInitialize_Enemy == false) {
        bInitialize_Enemy = true;
        init_enemy();
    }

    glViewport(0, 0, viewW, viewH);
    glClearColor(0.0f,0.0f,0.5f,1.0f);
    glClear(GL_COLOR_BUFFER_BIT /*| GL_DEPTH_BUFFER_BIT*/);

    glDisable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    calc_projection();
    lookAt(0.0f,0.0f,0.0f,0.0f,0.0f,-100.0f, 0.0f,1.0f,0.0f);
    set_projection();

    glUniform2f(screen_size, viewW, viewH);

    vtx2 = _vtx2;
    uv2 = _uv2;
    luminance2 = _luminance2;
    strides = 0;


    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_BLEND);

    drawSprite(tx_bg,0,0,1279,719,0,0,1280,720);

    glEnable(GL_BLEND);

    move_enemy();
    drawSpriteArrays(tx_enemy);


    glDisable(GL_BLEND);
    glDisable(GL_TEXTURE_2D);

    glFlush();

    return 0;

}

void Java_com_example_render2d_JniBridge_drawFPS(JNIEnv* env, jobject obj, int fps)
{

    char    str00[] = "Frame Rate = ";
    char    str01[] = "fps";
    putString(16,16,str00);
    putValue(16+16*13,16,fps);
    putString(16+16*13+16*2,16,str01);

}

void Java_com_example_render2d_JniBridge_ReleaseAll(JNIEnv* env, jobject obj) {

    int     i;

    for(i = 0;i < TEXTURE_MAX;i++) {
        textures[0] = texture[i].lpTexture;
        glDeleteTextures (1, textures);
    }
}



// [EOF]
